import cv2 as cv

img=cv.imread('Player.jpg')
patch=img[250:350,170:270,:]    # 세로 100px, 가로 100px, RGB채널 모두

img = cv.rectangle(img, (170,250),(270,350),(255,0,0),3) # 파란색 사각형
patch1=cv.resize(patch,dsize=(0,0),fx=5,fy=5,interpolation=cv.INTER_NEAREST)
patch2=cv.resize(patch,dsize=(0,0),fx=5,fy=5,interpolation=cv.INTER_LINEAR)
patch3=cv.resize(patch,dsize=(0,0),fx=5,fy=5,interpolation=cv.INTER_CUBIC)
# fx(가로), fy(세로) 5배 확대

cv.imshow('Original', img)
cv.imshow('Resize nearest', patch1) 
cv.imshow('Resize bilinear', patch2)
cv.imshow('resize bicubic', patch3)

cv.waitKey()
cv.destroyAllWindows()

