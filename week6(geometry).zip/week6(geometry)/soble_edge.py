import cv2 as cv

img=cv.imread('Player.jpg')
gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

grad_x= cv.Sobel(gray,cv.CV_32F, 1,0, ksize=3)  # 소벨 x연산자, 필터 크기는3x3, 1,0: 필터 방향
grad_y= cv.Sobel(gray,cv.CV_32F, 0,1, ksize=3)  # 소벨 y연산자, 0,1: 필터 방향(참고)

sobel_x = cv.convertScaleAbs(grad_x)
sobel_y = cv.convertScaleAbs(grad_y)

edge_strength=cv.addWeighted(sobel_x, 0.5, sobel_y, 0.5, 0)

cv.imshow('Original', gray)
cv.imshow('sobelx', sobel_x)
cv.imshow('sobely', sobel_y)
cv.imshow('edge strength', edge_strength) # sobelX+ sobelY -> 에지 강도를 나타냄

cv.waitKey()
cv.destroyAllWindows()
